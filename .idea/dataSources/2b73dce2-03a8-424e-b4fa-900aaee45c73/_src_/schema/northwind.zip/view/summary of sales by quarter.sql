CREATE VIEW `summary of sales by quarter` AS;
