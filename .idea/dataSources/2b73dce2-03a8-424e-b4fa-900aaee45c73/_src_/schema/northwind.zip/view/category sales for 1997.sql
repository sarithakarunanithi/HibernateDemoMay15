CREATE VIEW `category sales for 1997` AS;
