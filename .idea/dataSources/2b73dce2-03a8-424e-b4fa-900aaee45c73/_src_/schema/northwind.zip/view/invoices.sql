CREATE VIEW invoices AS;
