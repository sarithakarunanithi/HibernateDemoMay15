CREATE VIEW `alphabetical list of products` AS;
