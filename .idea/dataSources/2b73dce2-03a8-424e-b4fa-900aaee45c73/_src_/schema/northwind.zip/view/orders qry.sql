CREATE VIEW `orders qry` AS;
